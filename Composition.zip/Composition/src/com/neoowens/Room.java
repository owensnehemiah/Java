package com.neoowens;

/**
 * Created by Neo Owens on 4/10/2017.
 */
public class Room {

    private Bed bed;
    private Ceiling ceiling;
    private Wall wall1;
    private Wall wall2;
    private Wall wall3;
    private Wall wall4;

    private Furniture furniture;

    public Room(Bed bed, Ceiling ceiling, Wall wall1, Wall wall2, Wall wall3, Wall wall4, Furniture furniture) {
        this.bed = bed;
        this.ceiling = ceiling;
        this.wall1 = wall1;
        this.wall2 = wall2;
        this.wall3 = wall3;
        this.wall4 = wall4;
        this.furniture = furniture;
    }

    //redundant but trying this anyway
    public void makeBed() {
        System.out.println(" Request to make the bed.. ");
        bed.make();
    }

    //print out results chosen in main class.

    public void fillUp(){
        System.out.println("Room Set up: " + getBed() + " bed; " + getCeiling() + " ceiling; and walls facing " + getWall1()
                            + getWall2() + ", " + getWall3() + ", " + getWall4());
    }

    public Bed getBed() {
        return bed;
    }

    public Ceiling getCeiling() {
        return ceiling;
    }

    public Wall getWall1() {
        return wall1;
    }

    public Wall getWall2() {
        return wall2;
    }

    public Wall getWall3() {
        return wall3;
    }

    public Wall getWall4() {
        return wall4;
    }

    public Furniture getFurniture() {
        return furniture;
    }
}
