package com.neoowens;

/**
 * Created by Neo Owens on 4/11/2017.
 */
public class Wall {

    private String direction;

    public Wall(String direction){
        this.direction = direction;
    }

    public String getDirection() {
        return direction;
    }
}
