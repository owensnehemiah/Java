package com.neoowens;

public class Main {

    public static void main(String[] args) {
        //create walls in the room
        Wall wall1 = new Wall("West");
        Wall wall2 = new Wall("East");
        Wall wall3 = new Wall("North");
        Wall wall4 = new Wall("South");
        //create the bed etc
        Bed bed = new Bed("Queen", 4, 1, 1);

        //customize the ceiling...
        Ceiling ceiling = new Ceiling(15, "Blue");

        //pick amount of furniture...
        Furniture furniture = new Furniture(4, 1, 1, 1);

        //set up prints out the amount of furniture of each type
        furniture.setUp();

        //create the room using the variables above
        Room room = new Room(bed, ceiling, wall1, wall2, wall3, wall4, furniture);

        //call method to make bed in room class
        room.makeBed();

        //call method to fillUp room in room class...more or less a System.out.println to show the values that were chosen prior.
        //ISSUE: Address of instance variables found in heap (i think) are being shown instead of the instance variables.
        room.fillUp();

    }



}