package com.neoowens;

/**
 * Created by Neo Owens on 4/11/2017.
 */
public class Bed {

    private String style;
    private int pillows;
    private int sheets;
    private int comforter;

    public Bed (String style, int pillows, int sheets, int comforter) {
        this.style = style;
        this.pillows = pillows;
        this.sheets = sheets;
        this.comforter = comforter;
    }

    public void make(){
        System.out.println("Currently making the bed");
    }

    public String getStyle(){
        return style;
    }

    public int getPillows() {
        return pillows;
    }

    public int getSheets() {
        return sheets;
    }

    public int getComforter() {
        return comforter;
    }
}
