package com.neoowens;

/**
 * Created by Neo Owens on 4/10/2017.
 */
public class House {

    private Furniture theFurniture;
    private Room theRoom;

    public House(Furniture theFurniture, Room theRoom) {
        this.theFurniture = theFurniture;
        this.theRoom = theRoom;
    }


    // Furniture Constructor representing Furniture class
    private Furniture getTheFurniture() {
        return theFurniture;
    }
    // Room Constructore representing Room Class
    private Room getTheRoom() {
        return theRoom;
    }
}
