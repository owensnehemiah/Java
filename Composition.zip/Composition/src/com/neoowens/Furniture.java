package com.neoowens;

/**
 * Created by Neo Owens on 4/10/2017.
 */
public class Furniture {

    private int chairs;
    private int coatRack;
    private int cabinet;
    private int couch;

    public Furniture(int chairs, int coatRack, int cabinet, int couch) {
        this.chairs = chairs;
        this.coatRack = coatRack;
        this.cabinet = cabinet;
        this.couch = couch;
    }

    public void setUp() {
        System.out.println("Furniture Set Up: " + chairs + " chairs; " + coatRack + " coatracks; " + cabinet + " cabinet; " + couch + " couch; ");
    }
}
